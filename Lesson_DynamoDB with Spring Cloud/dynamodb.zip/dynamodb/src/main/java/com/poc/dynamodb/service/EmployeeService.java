package com.poc.dynamodb.service;

import com.poc.dynamodb.vo.EmployeeVo;

public interface EmployeeService {
    EmployeeVo saveData(EmployeeVo employeeVo);

    EmployeeVo findById(int id);
}
