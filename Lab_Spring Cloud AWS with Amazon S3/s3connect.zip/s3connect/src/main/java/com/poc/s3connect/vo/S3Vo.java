package com.poc.s3connect.vo;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@NoArgsConstructor
@AllArgsConstructor
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class S3Vo {

    public S3Vo(String bucketName) {
        this.bucketName = bucketName;
    }

    String bucketName;

    String message;


}
