package com.poc.s3connect.controller;


import com.poc.s3connect.service.S3Service;
import com.poc.s3connect.vo.FileResponseVo;
import com.poc.s3connect.vo.S3ObjectVo;
import com.poc.s3connect.vo.S3Vo;
import lombok.RequiredArgsConstructor;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

@RestController()
@RequiredArgsConstructor
public class S3Controller {

    private final S3Service s3Service;

    @GetMapping("/list-all-buckets")
    public ResponseEntity<List<S3Vo>> listBuckets() {
        return ResponseEntity.ok(s3Service.listBuckets());
    }

    @PostMapping("/create/{bucketName}")
    public ResponseEntity<S3Vo> createBucket(@PathVariable String bucketName) {
        return ResponseEntity.ok(s3Service.createS3Bucket(bucketName));
    }

    @GetMapping("/{bucketName}/{prefix}/list-all")
    public ResponseEntity<List<S3ObjectVo>> listAllObjects(@PathVariable String bucketName,@PathVariable String prefix) {
        return ResponseEntity.ok(s3Service.listAllObjects(bucketName, prefix));
    }

    @PostMapping(value = "/{bucketName}/upload", consumes = "multipart/form-data")
    public ResponseEntity<S3ObjectVo> upload(@PathVariable String bucketName,
                                       @RequestParam("path") String path, @RequestParam("file") MultipartFile file) throws IOException {
        return ResponseEntity.ok(s3Service.upload(bucketName, path, file));
    }

    @GetMapping("/{bucketName}/download/{path}/{file}")
    public ResponseEntity<InputStreamResource> downloadFile (@PathVariable String bucketName,
                                                             @PathVariable String path,
                                                             @PathVariable String file) throws IOException {

        FileResponseVo fileResponseVo = s3Service.download(bucketName,path, file);

        return ResponseEntity.ok()
                .contentType(fileResponseVo.getMimeType())
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + file + "\"")
                .body(new InputStreamResource(fileResponseVo.getFile()));
    }


}
