package com.poc.s3connect.controller;


import com.poc.s3connect.service.JwtService;
import com.poc.s3connect.service.impl.UserDetailsServiceImpl;
import com.poc.s3connect.vo.UserVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/auth")
public class UserController {

    @Autowired
    private UserDetailsServiceImpl userDetailsService;
    @Autowired
    private JwtService jwtService;
    @Autowired
    private  AuthenticationManager authenticationManager;

    @Value("${welcome.message}")
    private String welcome;

    @GetMapping("/welcome")
    public ResponseEntity<String> welcome() {
        return ResponseEntity.ok(welcome);
    }

    //add user removed

//    @PostMapping("/add-user")add
//    public ResponseEntity<String> addNewUser(@RequestBody UserVo userVo) {
//        return ResponseEntity,ok(userDetailsService.addUser(userVo));
//    }

    @PostMapping("/generate-token")
    public ResponseEntity<String> authenticateAndGetToken(@RequestBody UserVo authRequest) {
        Authentication authentication = authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(authRequest.getName(), authRequest.getPassword()));
        if (authentication.isAuthenticated()) {
            return ResponseEntity.ok(jwtService.generateToken(authRequest.getName()));
        } else {
            throw new UsernameNotFoundException("invalid user request !");
        }
    }
}
