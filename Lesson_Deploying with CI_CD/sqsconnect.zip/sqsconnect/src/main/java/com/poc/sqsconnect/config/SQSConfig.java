package com.poc.sqsconnect.config;

import io.awspring.cloud.sqs.operations.SqsTemplate;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.sqs.SqsAsyncClient;

@Component
public class SQSConfig {

    @Value("${aws.region}")
    private String region;

    @Bean
    public SqsAsyncClient sqsAsyncClient() {
        return SqsAsyncClient
                .builder()
                .region(Region.of(region))
                .build();
    }


    @Bean
    public SqsTemplate sqsTemplate (SqsAsyncClient sqsAsyncClient) {
        //.configure(sqsTemplateOptions -> sqsTemplateOptions.acknowledgementMode(TemplateAcknowledgementMode.ACKNOWLEDGE))
        return SqsTemplate.builder().sqsAsyncClient(sqsAsyncClient).build();
    }

}
