package com.poc.sqsconnect.repository;

import com.poc.sqsconnect.model.EmployerModel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface EmployerRepository extends JpaRepository<EmployerModel, Long> {
}
