package com.poc.sqsconnect.controller;


import com.poc.sqsconnect.service.EmployerService;
import com.poc.sqsconnect.vo.EmployerVo;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController()
@RequiredArgsConstructor
@RequestMapping("/api/v1")
public class EmployerController {

    private final EmployerService employerService;

    @GetMapping("/employer/{id}")
    public ResponseEntity<EmployerVo> getEmployer(@PathVariable long id) {
        return ResponseEntity.ok(employerService.getEmployer(id));
    }

    //add user removed

    @PostMapping("/add-employer")
    public ResponseEntity<EmployerVo> addNewUser(@RequestBody EmployerVo employerVo) {
        return ResponseEntity.ok(employerService.createEmployer(employerVo.getName()));
    }


}
