package com.poc.sqsconnect.service;

import com.poc.sqsconnect.vo.EmployerVo;

public interface EmployerService {

    EmployerVo createEmployer(String name);

    EmployerVo getEmployer(long id);
}
