package com.poc.sqsconnect.service.impl;

import com.poc.sqsconnect.model.EmployerModel;
import com.poc.sqsconnect.repository.EmployerRepository;
import com.poc.sqsconnect.service.EmployerService;
import com.poc.sqsconnect.vo.EmployerVo;
import lombok.RequiredArgsConstructor;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service("EmployerServiceImpl")
@RequiredArgsConstructor
public class EmployerServiceImpl implements EmployerService {
    private static final Logger logger =  LogManager.getLogger(EmployerServiceImpl.class);

    private final EmployerRepository employerRepository;
    @Override
    public EmployerVo createEmployer(String name) {
        logger.info("Create Employer : {}", name);
        EmployerModel employerModel = new EmployerModel();
        employerModel.setName(name);
        employerRepository.save(employerModel);
        return new EmployerVo(employerModel.getId(), name);
    }

    @Override
    public EmployerVo getEmployer(long id) {
        logger.info("Get Employer : {}", id);
        Optional<EmployerModel> employerModelOptional = employerRepository.findById(id);
        return employerModelOptional.map(employerModel -> {
            EmployerVo employerVo = new EmployerVo();
            employerVo.setId(employerModel.getId());
            employerVo.setName(employerModel.getName());
            return employerVo;
        }).orElse(null);

    }
}
