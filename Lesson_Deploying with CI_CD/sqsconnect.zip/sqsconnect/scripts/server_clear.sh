#!/usr/bin/env bash
sudo rm -rf /home/ec2-user/server