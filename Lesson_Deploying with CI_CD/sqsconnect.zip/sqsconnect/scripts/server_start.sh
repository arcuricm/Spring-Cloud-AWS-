#!/usr/bin/env bash
cd /home/ec2-user/server
sudo java -jar sqsconnect*.jar > /dev/null 2> /dev/null < /dev/null &