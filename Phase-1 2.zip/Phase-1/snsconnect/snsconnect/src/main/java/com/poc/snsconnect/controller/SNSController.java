package com.poc.snsconnect.controller;

import com.poc.snsconnect.service.SnsService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("sns/v1/")
@RequiredArgsConstructor
public class SNSController {

    private  final SnsService snsService;

    @PostMapping(value = "push-message")
    ResponseEntity<String> pushMessage(@RequestBody String message) {

        return ResponseEntity.ok(snsService.pushMessage(message));
    }
}
