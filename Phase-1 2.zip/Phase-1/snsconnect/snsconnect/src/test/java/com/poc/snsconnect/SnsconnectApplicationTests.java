package com.poc.snsconnect;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SnsconnectApplicationTests {

    @Test
    void contextLoads() {
    }

}
