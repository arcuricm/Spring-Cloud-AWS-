package com.poc.sqsconnect;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SqsconnectApplicationTests {

    @Test
    void contextLoads() {
    }

}
