package com.poc.sqsconnect.service;



public interface SQSService {
    String pushMessage(String message);

    void getMessage(String message);
}
