package com.poc.sqsconnect.controller;

import com.poc.sqsconnect.service.SQSService;
import io.awspring.cloud.sqs.annotation.SqsListener;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequiredArgsConstructor
public class SQSController {

    private final SQSService sqsService;

    @PostMapping(value = "push-message")
    ResponseEntity<String> pushMessage(@RequestBody String message) {

        return ResponseEntity.ok(sqsService.pushMessage(message));
    }

    @SqsListener("dinuka-sqs")
    public void getMessageFromSqs(String message) {
        sqsService.getMessage(message);
    }


}
