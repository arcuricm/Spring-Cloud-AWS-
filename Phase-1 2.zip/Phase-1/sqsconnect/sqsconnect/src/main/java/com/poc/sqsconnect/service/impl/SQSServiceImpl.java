package com.poc.sqsconnect.service.impl;

import com.poc.sqsconnect.service.SQSService;
import io.awspring.cloud.sqs.operations.SqsTemplate;
import lombok.RequiredArgsConstructor;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service("sqsService")
@RequiredArgsConstructor
public class SQSServiceImpl implements SQSService {

    private static final Logger logger =  LogManager.getLogger(SQSServiceImpl.class);

    @Value("${aws.sqs.name}")
    private String sqs;


    private final SqsTemplate sqsTemplate;
    @Override
    public String pushMessage(String message) {
        logger.info("Send message to SQS");
        sqsTemplate.send(sqs, message);
        return message;
    }

    @Override
    public void getMessage(String message) {
        logger.info("Message Received");
        logger.info("Message : {}", message);
    }
}
