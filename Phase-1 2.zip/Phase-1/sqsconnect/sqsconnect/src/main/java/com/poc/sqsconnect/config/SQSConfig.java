package com.poc.sqsconnect.config;

import io.awspring.cloud.sqs.operations.SqsTemplate;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;
import software.amazon.awssdk.auth.credentials.AwsBasicCredentials;
import software.amazon.awssdk.auth.credentials.StaticCredentialsProvider;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.sqs.SqsAsyncClient;

@Component
public class SQSConfig {

    @Value("${aws.region}")
    private String region;

    @Value("${aws.access.key}")
    private String accessKey;

    @Value("${aws.secret.key}")
    private String secretKey;

    @Bean
    public SqsAsyncClient sqsAsyncClient() {
        return SqsAsyncClient
                .builder()
                .credentialsProvider(StaticCredentialsProvider.create(AwsBasicCredentials.create(accessKey, secretKey)))
                .region(Region.of(region))
                .build();
    }


    @Bean
    public SqsTemplate sqsTemplate (SqsAsyncClient sqsAsyncClient) {
        //.configure(sqsTemplateOptions -> sqsTemplateOptions.acknowledgementMode(TemplateAcknowledgementMode.ACKNOWLEDGE))
        return SqsTemplate.builder().sqsAsyncClient(sqsAsyncClient).build();
    }

}
