package com.poc.s3connect.service;

import com.poc.s3connect.vo.FileResponseVo;
import com.poc.s3connect.vo.S3ObjectVo;
import com.poc.s3connect.vo.S3Vo;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

public interface S3Service {

    List<S3Vo> listBuckets();

    S3Vo createS3Bucket(String bucketName);

    List<S3ObjectVo> listAllObjects(String bucketName, String prefix);

    S3ObjectVo upload(String bucketName, String path, MultipartFile file) throws IOException;

    FileResponseVo download(String bucketName,String path, String file) throws IOException;
}
