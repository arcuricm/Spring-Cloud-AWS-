package com.poc.s3connect.exception;

import com.poc.s3connect.vo.ExceptionVo;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(Exception.class)
    public ResponseEntity<ExceptionVo> exception(Exception e) {
        return new ResponseEntity(new ExceptionVo(e.getMessage()), HttpStatus.BAD_REQUEST);
    }
}
