package com.poc.dynamodb.controller;

import com.poc.dynamodb.service.EmployeeService;
import com.poc.dynamodb.vo.EmployeeVo;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequiredArgsConstructor
public class EmployeeController {

    private final EmployeeService employeeService;

    @PostMapping("/employee")
    public ResponseEntity<EmployeeVo> saveMovie(@RequestBody EmployeeVo employeeVo) {
        return ResponseEntity.ok(employeeService.saveData(employeeVo));
    }

    @GetMapping("/employee/{id}")
    public ResponseEntity<EmployeeVo> findById(@PathVariable("id") int id) {
        return ResponseEntity.ok(employeeService.findById(id));
    }
}
