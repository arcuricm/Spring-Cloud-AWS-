package com.poc.dynamodb.service.impl;

import com.poc.dynamodb.model.Employee;
import com.poc.dynamodb.service.EmployeeService;
import com.poc.dynamodb.vo.EmployeeVo;
import io.awspring.cloud.dynamodb.DynamoDbTemplate;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import software.amazon.awssdk.enhanced.dynamodb.Key;

@Service("employeeService")
@RequiredArgsConstructor
public class EmployeeServiceImpl implements EmployeeService {

    private final DynamoDbTemplate dynamoDbTemplate;
    @Override
    public EmployeeVo saveData(EmployeeVo employeeVo) {
        Employee employee = new Employee(employeeVo.getId(),employeeVo.getName());
        dynamoDbTemplate.save(employee);
        return employeeVo;
    }

    @Override
    public EmployeeVo findById(int id) {
        Key key = Key.builder().partitionValue(id).build();
        Employee employee = dynamoDbTemplate.load(key, Employee.class);
        return new EmployeeVo(employee.getId(), employee.getName());
    }
}
