package com.poc.snsconnect.service.Impl;

import com.poc.snsconnect.service.SnsService;
import io.awspring.cloud.sns.core.SnsTemplate;
import lombok.RequiredArgsConstructor;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class SnsServiceImpl implements SnsService {

    private static final Logger logger =  LogManager.getLogger(SnsServiceImpl.class);

    @Value("${aws.sns.name}")
    private String sns;

    private  final SnsTemplate snsTemplate;
    @Override
    public String pushMessage(String message) {
        logger.info("Send message to SNS");
        snsTemplate.convertAndSend(sns, message);
        return message;
    }

    @Override
    public void getMessage(String message, String subject) {
        logger.info("Message Received {}, subject {}", message, subject);
    }
}
