package com.poc.snsconnect.service;

public interface SnsService {
    String pushMessage(String message);

    void getMessage(String message, String subject);
}
