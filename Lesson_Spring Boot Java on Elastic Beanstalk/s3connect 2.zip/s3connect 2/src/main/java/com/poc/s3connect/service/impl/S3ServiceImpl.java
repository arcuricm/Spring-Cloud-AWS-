package com.poc.s3connect.service.impl;

import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.util.IOUtils;
import com.poc.s3connect.service.S3Service;
import com.poc.s3connect.vo.FileResponseVo;
import com.poc.s3connect.vo.S3ObjectVo;
import com.poc.s3connect.vo.S3Vo;
import io.awspring.cloud.s3.S3Resource;
import io.awspring.cloud.s3.S3Template;
import lombok.RequiredArgsConstructor;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.util.MimeTypeUtils;
import org.springframework.web.multipart.MultipartFile;
import software.amazon.awssdk.services.s3.S3Client;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;
@Service("s3ServiceImpl")
@RequiredArgsConstructor
public class S3ServiceImpl implements S3Service {

    private  static final String PATH_SEPARATOR = "/";

    private static final Logger logger =  LogManager.getLogger(S3ServiceImpl.class);

    private  final S3Template s3Template; // spring cloud 3 template for s3

    private final AmazonS3 amazonS3; // old version s3 sdk

    private final S3Client s3Client; // s3 sdk
    @Override
    public List<S3Vo> listBuckets() {
        logger.info("List S3 Buckets");
        return s3Client.listBuckets().buckets().stream().map(bucket -> new S3Vo(bucket.name())).toList();
    }

    @Override
    public S3Vo createS3Bucket(String bucketName) {
        logger.info("Create S3 Bucket");
        S3Vo bucket = new S3Vo();
        boolean isBucketExist;
        try {
            isBucketExist = amazonS3.doesBucketExistV2(bucketName);
        } catch (Exception e) {
            isBucketExist = true;
            logger.info("Bucket name already in use");
        }
        if (isBucketExist) {
            bucket.setMessage("Bucket name already in use. Try another name.");
        } else {
            s3Template.createBucket(bucketName);
            bucket.setBucketName(bucketName);
            bucket.setMessage("Bucket Successfully Created");
        }

        return bucket;
    }

    @Override
    public List<S3ObjectVo> listAllObjects(String bucketName, String prefix) {
        logger.info("List objects in {} bucket, prefix {}", bucketName, prefix);
        return s3Template.listObjects(bucketName,prefix).stream().map(objectSummary -> new S3ObjectVo(objectSummary.getFilename())).toList();
    }

    @Override
    public S3ObjectVo upload(String bucketName, String path, MultipartFile file) throws IOException {
        logger.info("List objects in {} bucket , {} path ", bucketName, path);
        String filePath;
        if (path!= null) {
            filePath = path + PATH_SEPARATOR + file.getOriginalFilename();
        } else {
            filePath = file.getOriginalFilename();
        }
        assert filePath != null;
        s3Template.upload(bucketName, filePath, file.getInputStream());
        return  new S3ObjectVo(file.getOriginalFilename());
    }

    @Override
    public FileResponseVo download(String bucketName, String path, String file) throws IOException {
        String filePath;
        String contentType;
        InputStream is;
        if (path!= null) {
            filePath = path + PATH_SEPARATOR + file;
        } else {
            filePath = file;
        }
        S3Resource object = s3Template.download(bucketName, filePath);
        try(InputStream stream = object.getInputStream()) {
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            IOUtils.copy(stream, byteArrayOutputStream);
            is = new ByteArrayInputStream(byteArrayOutputStream.toByteArray());
            contentType = object.contentType();
        }
        return new FileResponseVo(is, MediaType.asMediaType(MimeTypeUtils.parseMimeType(contentType)));
    }
}
