package com.poc.s3connect.service.impl;

import com.poc.s3connect.config.security.UserInfoDetails;
import com.poc.s3connect.model.UserModel;
import com.poc.s3connect.repository.UserRepository;
import com.poc.s3connect.vo.UserVo;
import lombok.RequiredArgsConstructor;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service("UserDetailsServiceImpl")
public class UserDetailsServiceImpl implements UserDetailsService {

    private static final Logger logger =  LogManager.getLogger(UserDetailsServiceImpl.class);

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PasswordEncoder encoder;

    @Override
    public UserDetails loadUserByUsername(String name) throws UsernameNotFoundException {

        logger.info("Load user: {}", name);

        Optional<UserModel> userDetail = userRepository.findByName(name);
        // Converting userDetail to UserDetails
        return userDetail.map(UserInfoDetails::new)
                .orElseThrow(() -> new UsernameNotFoundException("User not found " + name));
    }

    public String addUser(UserVo userVo) {
        logger.info("Add user: {}",  userVo.getName());
        UserModel user = new UserModel();
        user.setName(userVo.getName());
        user.setPassword(encoder.encode(userVo.getPassword()));
        userRepository.save(user);
        return "User Added Successfully";
    }
}
