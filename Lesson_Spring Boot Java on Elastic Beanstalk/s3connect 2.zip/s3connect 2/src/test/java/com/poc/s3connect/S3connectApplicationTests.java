package com.poc.s3connect;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class S3connectApplicationTests {

	@Test
	void contextLoads() {
	}

}
